/*MissileCraft Mod*/
/*By: Andr3w246*/
/*COPYRIGHT ANDR3W246 (c) 2015*/

//Variables
var version= "0.4alpha"
var setX= 0
var setY= 0
var setZ= 0
var set2X= 0
var set2Y= 0
var set2Z= 0
var targetSet= 0
var targetSet2= 0
var launchX= 0
var launchY= 0
var launchZ= 0
var addY= 0
var subY= 50
var add2Y= 0
var sub2Y= 50
var launchSet= 0
var iron= "missile"
var inAir= 0
var mTick= 0
var ud= 0
var mid= 0
var fTicks= 0

//New Blocks
Block.defineBlock(23, "Launch Platform", ["platform", 0], 1, false, 0);
Block.setDestroyTime(23, 5);
Block.setLightOpacity(23, 0);
Block.setColor(23, [0x555555]);
Block.setShape(23, 0, 0, 0, 1, 0.5, 1);
Item.addShapedRecipe(23, 1, 0, ["000","sss","iii"], ["s",1,0,"i",265,0]);
Item.setCategory(23, ItemCategory.TOOL);

Block.defineBlock(29, "Launch Control Panel", [["redstone_block", 0],["panel", 0],["stone", 0],["stone", 0],["stone", 0],["stone", 0]], 1, false, 0);
Block.setDestroyTime(29, 5);
Block.setLightOpacity(29, 0);
Block.setShape(29, 0.25, 0, 0.25, 0.75, 1, 0.75);
Item.addShapedRecipe(29, 1, 0, ["rr0","ii0","ii0"],["r",331,0,"i",265,0]);
Item.setCategory(29, ItemCategory.TOOL);

Block.defineBlock(33, "Conventional Missile", [["engine",0],["nose",0],[iron,0],[iron,0],[iron,0],[iron,0]], 20, false, 0);
Block.setDestroyTime(33, 0.1);
Block.setLightOpacity(33, 0);
Block.setShape(33, 0.1, -0.5, 0.1, 0.9, 1.25, 0.9);
Item.addShapedRecipe(33, 1, 0, ["0p0","iti","ili"],["p",70,0,"i",265,0,"t",46,0,"l",325,10]);
Item.setCategory(33, ItemCategory.TOOL);

Block.defineBlock(34, "Breaching Missile", [["engine",0],["nose",1],[iron,1],[iron,1],[iron,1],[iron,1]], 20, false, 0);
Block.setDestroyTime(34, 0.1);
Block.setLightOpacity(34, 0);
Block.setShape(34, 0.1, -0.5, 0.1, 0.9, 1.5, 0.9);
Item.addShapedRecipe(34, 1, 0, ["0t0","0t0","0m0"],["t",46,0,"m",33,0]);
Item.setCategory(34, ItemCategory.TOOL);

Block.defineBlock(36, "Nuclear Missile", [["engine",0],["nose",2],[iron,2],[iron, 2],[iron,2],[iron,2]], 20, false, 0);
Block.setDestroyTime(36, 0.1);
Block.setLightOpacity(36, 0);
Block.setShape(36, 0.1, -0.5, 0.1, 0.9, 2.5, 0.9);
Item.addShapedRecipe(36, 1, 0, ["ttt","0t0","0m0"], ["t",46,0,"m",33,0]);
Item.setCategory(36, ItemCategory.TOOL);

Block.defineBlock(84, "Thermobaric Missile", [["engine",0],["nose",3],[iron,3],[iron,3],[iron,3],[iron,3]], 20, false, 0);
Block.setDestroyTime(84, 0.1);
Block.setLightOpacity(84, 0);
Block.setShape(84, 0.1, -0.5, 0.1, 0.9, 3, 0.9);
Item.setCategory(84, ItemCategory.TOOL);

Block.defineBlock(93, "Ender Missile", [["engine",0],["nose",4],[iron,4],[iron,4],[iron,4],[iron,4]], 20, false, 0);
Block.setDestroyTime(93, 0.1);
Block.setLightOpacity(93, 0);
Block.setShape(93, 0.1, -0.5, 0.1, 0.9, 2, 0.9);
Item.addShapedRecipe(93, 1, 0, ["s0s","btb","0m0"], ["s",1,0,"b",351,15,"t",46,0,"m",33,0]);
Item.setCategory(93, ItemCategory.TOOL);

Block.defineBlock(94, "Napalm Missile" ,[["engine",0],["nose",5],[iron,5],[iron,5],[iron,5],[iron,5]],20, false, 0);
Block.setDestroyTime(94, 0.1);
Block.setLightOpacity(94, 0);
Block.setShape(94, 0.1, -0.5, 0.1, 0.9, 2, 0.9);
Item.addShapedRecipe(94, 1, 0, ["0f0","0t0","0m0"],["f",259,0,"t",46,0,"m",33,0]);
Item.setCategory(94, ItemCategory.TOOL);

//New Items
ModPE.setItem(500, "pointer", 0, "Position Definer");
Item.setCategory(500, ItemCategory.TOOL);
ModPE.setItem(501, "box", 0, "Missile Platform Maker");
Item.addShapedRecipe(501, 1, 0, ["000","0p0","0l0"], ["p",23,0,"l",29,0]);
Item.setCategory(501, ItemCategory.TOOL);

function useItem(x, y, z, itemId, blockId, side){
if(itemId==500&&blockId==23){
launchX= x
launchY= y
launchZ= z
launchSet= 1
clientMessage("§2Launch Platform set!");
}
if(itemId==500&&launchSet!=1&&blockId!=29){
clientMessage("§4Launch Platform not set! Please tap this item on one to set it!");
}
if(itemId==500&&launchSet==1&&blockId!=23&&blockId!=29){
setX= x
setY= y
setZ= z
targetSet= 1
clientMessage("§2Target set to [X: "+setX+",Y: "+setY+",Z: "+setZ+"]");
}
if(blockId==29){
var check= Level.getTile(x, y+1, z+1);
if (check!=0&&targetSet==1){
inAir= 1
addY= launchY+1
mid= check
Level.setTile(launchX, launchY+1, launchZ, 0);
clientMessage("Missile Launched!");
}
if(targetSet==0){
clientMessage("§4No Target set! Please set a target with the position definer!");
}
if(check!=33&&check!=34&&check!=36&&check!=84&&check!=93&&check!=94){
clientMessage("§4No Missile loaded!");
}
if(launchSet!=1){
clientMessage("§4No set Launch Platform!");
}
}
if(itemId==501){
Level.setTile(x, y+1, z, 29);
Level.setTile(x, y+1, z+1, 23);
}
if(itemId==23||itemId==29){
preventDefault();
clientMessage("§6You cannot place this block down.");
}
if(itemId==500&&blockId==29){
clientMessage("Please do not tap the launcher with the position definer!");
}
}

function newLevel(){
clientMessage("MissileCraft Mod Ver: §6"+version);
clientMessage("By: §6Andr3w246");
Player.addItemCreativeInv(33, 1, 0);
Player.addItemCreativeInv(34, 1, 0);
Player.addItemCreativeInv(36, 1, 0);
Player.addItemCreativeInv(84, 1, 0);
Player.addItemCreativeInv(93, 1, 0);
Player.addItemCreativeInv(94, 1, 0);
Player.addItemCreativeInv(500, 1, 0);
Player.addItemCreativeInv(501, 1, 0);
}

function modTick(){
if(inAir==1){
mTick++
if(mTick==5&&fTicks!=50&&ud==0){
mTick= 0
addY++
fTicks++
Level.setTile(launchX, addY-1, launchZ, 0);
Level.setTile(launchX, addY, launchZ, mid);
Level.addParticle(ParticleType.cloud, launchX+0.5, addY-1.25, launchZ+0.5, 0, 0, 0, 500);
Level.addParticle(ParticleType.cloud, launchX+0.5, addY-1.25, launchZ+0.5, 0, 0, 0, 500);
}
if(mTick==5&&fTicks==50){
mTick= 0
Level.setTile(launchX, addY, launchZ, 0);
addY= 0
fTicks= 0
ud= 1
}
if(mTick==5&&subY!=0&&ud==1){
mTick= 0
subY--
Level.setTile(setX, setY+subY+1, setZ, 0);
Level.setTile(setX, setY+subY, setZ, mid);
}
if(mTick==5&&subY==0){
mTick= 0
inAir= 0
ud= 0
subY= 50
Level.setTile(setX, setY+subY, setZ, 0);
if(mid==33){
explode(setX+0.5, setY, setZ+0.5, 10);
}
if(mid==34){
explode(setX+0.5, setY, setZ+0.5, 5);
explode(setX+0.5, setY-2.5, setZ+0.5, 5);
explode(setX+0.5, setY-5, setZ+0.5, 5);
explode(setX+0.5, setY-7.5, setZ+0.5, 5);
explode(setX+0.5, setY-10, setZ+0.5, 5);
}
if(mid==36){
explode(setX+0.5, setY, setZ+0.5, 50);
}
if(mid==84){
explode(setX+0.5, setY, setZ+0.5, 250);
explode(setX+12.5, setY, setZ+0.5, 250);
explode(setX-12.5, setY, setZ-0.5, 250);
explode(setX+0.5, setY, setZ+12.5, 250);
explode(setX-0.5, setY, setZ-12.5, 250);
}
if(mid==93){
explode (setX+0.5, setY, setZ+0.5, 15);
for(a=0; a<20; a++){
for(b=0; b<20; b++){
for(c=0; c<20; c++){
var ran= Math.random()*100
if(ran>=95){
Level.setTile(setX-10+a, setY-10+b, setZ-10+c, 121);
}
}}}
}
if(mid==94){
explode(setX+0.5, setY, setZ+0.5, 10);
for(a=0; a<30; a++){
for(b=0; b<30; b++){
for(c=0; c<30; c++){
var ran= Math.random()*100
if(ran>=70){
var check1= Level.getTile(setX-15+a, setY-15+b, setZ-15+c);
var check2= Level.getTile(setX-15+a, setY-16+b, setZ-15+c);
if(check1==0&&check2!=0&&check2!=51){
Level.setTile(setX-15+a, setY-15+b, setZ-15+c, 51);
}
}
}}}
}
targetSet= 0
}
}
}
